A Pen created at CodePen.io. You can find this one at http://codepen.io/diegoleme/pen/rIokB.

 Adapted from the following Flash:
http://img0.liveinternet.ru/images/attach/c/5//3970/3970473_sprite198.swf